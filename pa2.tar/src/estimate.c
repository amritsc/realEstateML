#include <stdio.h>
#include <stdlib.h>

void PrintRow(double *X, int n) {
    for (int i = 0; i < n; i++) {
        printf("%.0lf", X[i]);
        if (i != n - 1) {
            printf(" ");
        }
    }
    printf("\n");
}

void PrintMatrix(double **X, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        PrintRow(X[i], cols);
    }
}

double* NewRow(int n) {
    double *X = malloc(sizeof(double) * n);
    for (int i = 0; i < n; i++) {
        X[i] = 0;
    }
    return X;
}

double** NewMatrix(int r, int c) {
    double **X = malloc(sizeof(double*) * r);
    for (int i = 0; i < r; i++) {
        X[i] = NewRow(c);
    }
    return X;
}

void CopyRow(int n, double *src, double *dest) {
    for (int i = 0; i < n; i++) {
        dest[i] = src[i];
    }
}

void CopyMatrix(int r, int c, double **src, double **dest) {
    for (int i = 0; i < r; i++) {
	for (int j = 0; j < c; j++) {
	    dest[i][j] = src[i][j];
	}
    }
}

void FreeRow(double *X) {
    free(X);
}

void FreeMatrix(double **X, int rows) {
    for (int i = 0; i < rows; i++) {
        free(X[i]);
    }
    free(X);
}

void SubtractRows(double *X, int n, double *Y) {
    for (int i = 0; i < n; i++) {
        X[i] -= Y[i];
    }
}

void MultiplyRow(double* X, int n, double factor) {
    for (int i = 0; i < n; i++) {
        X[i] *= factor;
    }
}

void MultiplyMatrices(double **A, int aRows, int aCols, double **B, int bRows, int bCols, double **Product) {
    for (int i = 0; i < aRows; i++) {
        for (int j = 0; j < bCols; j++) {
            Product[i][j] = 0;
            for (int x = 0; x < aCols; x++) {
                Product[i][j] += A[i][x] * B[x][j];
            }
        }
    }
}

void TransposeMatrix(double **X, int rows, int cols, double **T) {
    for (int i = 0; i < cols; i++) {
        for (int j = 0; j < rows; j++) {
            T[i][j] = X[j][i];
        }
    }
}

void InvertMatrix(double **X, int size, double **N) {
    double **M = NewMatrix(size, size);
    CopyMatrix(size, size, X, M);
    for (int i = 0; i < size; i++) {
        N[i][i] = 1;
    }

    for (int p = 0; p < size; p++) {
        double f1 = M[p][p];
        MultiplyRow(M[p], size, 1.0 / f1);
        MultiplyRow(N[p], size, 1.0 / f1);

        double *mp_mip;
        double *np_mip;
        for (int i = p + 1; i < size; i++) {
            double f2 = M[i][p];

            mp_mip = NewRow(size);
            CopyRow(size, M[p], mp_mip);
            MultiplyRow(mp_mip, size, f2);

            np_mip = NewRow(size);
            CopyRow(size, N[p], np_mip);
            MultiplyRow(np_mip, size, f2);

            SubtractRows(M[i], size, mp_mip);
            SubtractRows(N[i], size, np_mip);

            FreeRow(mp_mip);
            FreeRow(np_mip);
        }
    }

    for (int p = size - 1; p >= 0; p--) {
        double *mp_mip;
        double *np_mip;
        for (int i = p - 1; i >= 0; i--) {
            double f = M[i][p];

            mp_mip = NewRow(size);
            CopyRow(size, M[p], mp_mip);
            MultiplyRow(mp_mip, size, f);

            np_mip = NewRow(size);
            CopyRow(size, N[p], np_mip);
            MultiplyRow(np_mip, size, f);

            SubtractRows(M[i], size, mp_mip);
            SubtractRows(N[i], size, np_mip);

            FreeRow(mp_mip);
            FreeRow(np_mip);
        }
    }

    FreeMatrix(M, size);
}

int main(int argc, char *argv[]) {

    int k, n;

    // training
    FILE *train_file, *data_file;
    train_file = fopen(argv[1], "r");

    if (train_file == NULL) {
        printf("Training file is empty/doesn't exist\n");
        return 0;
    }

    fscanf(train_file, "train\n"); // "train" line
    fscanf(train_file, "%d\n", &k);
    fscanf(train_file, "%d\n", &n);

    double **X = NewMatrix(n, k + 1);
    double **Y = NewMatrix(n, 1);
    for (int i = 0; i < n; i++) {
        X[i][0] = 1;
        for (int j = 0; j < k; j++) {
            fscanf(train_file, "%lf ", &X[i][j+1]);
        }
        fscanf(train_file, "%lf\n", &Y[i][0]);
    }

    fclose(train_file);

    double **XT = NewMatrix(k + 1, n);
    TransposeMatrix(X, n, k + 1, XT);

    double **XTX = NewMatrix(k + 1, k + 1);
    MultiplyMatrices(XT, k + 1, n, X, n, k + 1, XTX);

    double **XTXI = NewMatrix(k + 1, k + 1);
    InvertMatrix(XTX, k + 1, XTXI);

    double **XTXIXT = NewMatrix(k + 1, n);
    MultiplyMatrices(XTXI, k + 1, k + 1, XT, k + 1, n, XTXIXT);

    double **W = NewMatrix(k + 1, 1);
    MultiplyMatrices(XTXIXT, k + 1, n, Y, n, 1, W);

    FreeMatrix(X, n);
    FreeMatrix(Y, n);
    FreeMatrix(XT, k + 1);
    FreeMatrix(XTX, k + 1);
    FreeMatrix(XTXI, k + 1);
    FreeMatrix(XTXIXT, k + 1);

    // predictions
    data_file = fopen(argv[2], "r");

    if (data_file == NULL) {
        printf("Data file is empty/doesn't exist\n");
        return 0;
    }

    fscanf(data_file, "data\n");
    fscanf(data_file, "%d\n", &k);
    fscanf(data_file, "%d\n", &n);

    X = NewMatrix(n, k + 1);
    for (int i = 0; i < n; i++) {
        X[i][0] = 1;
        for (int j = 0; j < k; j++) {
            fscanf(data_file, "%lf", &X[i][j+1]);
            if (j != k - 1) {
                fscanf(data_file, " ");
            }
        }
    }

    fclose(data_file);

    Y = NewMatrix(n, 1);
    MultiplyMatrices(X, n, k + 1, W, k + 1, 1, Y);
    PrintMatrix(Y, n, 1);

    FreeMatrix(X, n);
    FreeMatrix(W, k + 1);
    FreeMatrix(Y, n);
    
    return 0;

}
